package com.lulu.assistant

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.util.Locale
import kotlin.concurrent.thread

class LuluService : Service(), TextToSpeech.OnInitListener {
    private val h = Handler(Looper.getMainLooper())
    private var speech: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var running = false
    private val wakeWords = listOf("لؤلؤ", "لولو", "لؤلؤه")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("ar")
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "lulu"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "لؤلؤ", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, ch)
            .setContentTitle("لؤلؤ شغّال").setContentText("بسمع اسمي...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        if (!running) {
            running = true
            thread {
                try { Engine.load(this) } catch (e: Exception) {
                    UiLog.d("الموديلات مش موجودة في assets: ${e.message}")
                    h.post { stopSelf() }; return@thread
                }
                h.post { listenWake() }
            }
        }
        return START_STICKY
    }

    private fun begin(rec: Recognizer, l: L) {
        speech?.shutdown()
        speech = SpeechService(rec, 16000f).also { it.startListening(l) }
    }

    /** وضع الانتظار: بيسمع كلمة "لؤلؤ" بس (قاموس محدود = خفيف ودقيق). */
    private fun listenWake() {
        val rec = Recognizer(Engine.model, 16000f, "[\"لؤلؤ\", \"لولو\", \"[unk]\"]")
        rec.setSpeakerModel(Engine.spk)
        begin(rec, object : L() {
            override fun onResult(hypothesis: String?) { onWake(hypothesis ?: return) }
        })
    }

    private fun onWake(json: String) {
        val r = VoiceId.parse(json)
        if (wakeWords.none { r.text.contains(it) }) return
        val me = VoiceId.load(this)
        if (me == null) { say("سجّل صوتك الأول من التطبيق") { listenWake() }; return }
        if (r.spk != null && r.frames >= VoiceId.MIN_FRAMES_WAKE) {
            val d = VoiceId.dist(me, r.spk)
            UiLog.d("اسم: المسافة ${"%.2f".format(d)}")
            if (d > VoiceId.LOOSE) return   // مش صوتك
        }
        say("أيوه") { listenCommand() }
    }

    /** وضع الأمر: كلام كامل + تحقق صارم من صوتك. */
    private fun listenCommand() {
        val rec = Recognizer(Engine.model, 16000f)
        rec.setSpeakerModel(Engine.spk)
        val timeout = Runnable { UiLog.d("محدش اتكلم"); listenWake() }
        h.postDelayed(timeout, 10000)
        begin(rec, object : L() {
            override fun onResult(hypothesis: String?) {
                val r = VoiceId.parse(hypothesis ?: return)
                if (r.text.isBlank()) return
                h.removeCallbacks(timeout)
                val me = VoiceId.load(this@LuluService)
                val d = if (r.spk != null && me != null) VoiceId.dist(me, r.spk) else 9.0
                UiLog.d("أمر: ${r.text} | مسافة ${"%.2f".format(d)} | frames ${r.frames}")
                if (d > VoiceId.THRESHOLD) { listenWake(); return }   // مش صوتك
                say(Commands.run(this@LuluService, r.text)) { listenWake() }
            }
        })
    }

    /** يتكلم ويقفل المايك وقت الكلام عشان ما يسمعش نفسه. */
    private fun say(text: String, then: () -> Unit) {
        speech?.shutdown(); speech = null
        val t = tts
        if (t == null || !ttsReady) { then(); return }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onError(u: String?) { h.post { then() } }
            override fun onDone(u: String?) { h.postDelayed({ then() }, 300) }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, System.nanoTime().toString())
    }

    override fun onDestroy() {
        running = false
        speech?.shutdown(); tts?.shutdown()
        super.onDestroy()
    }
}
