package com.lulu.assistant

import android.content.Context
import android.content.res.AssetManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.SpeakerModel
import org.vosk.android.RecognitionListener
import java.io.File
import java.io.IOException
import kotlin.math.sqrt

/** تحميل موديلات Vosk (الكلام + بصمة الصوت) مرة واحدة. */
object Engine {
    var model: Model? = null
    var spk: SpeakerModel? = null

    @Synchronized
    fun load(ctx: Context) {
        if (model != null) return
        val a = copyAssets(ctx, "model-ar")
        val b = copyAssets(ctx, "model-spk")
        model = Model(a)
        spk = SpeakerModel(b)
    }

    private fun copyAssets(ctx: Context, path: String): String {
        val out = File(ctx.filesDir, path)
        if (File(out, ".done").exists()) return out.absolutePath
        copyDir(ctx.assets, path, out)
        File(out, ".done").writeText("1")
        return out.absolutePath
    }

    private fun copyDir(am: AssetManager, src: String, dst: File) {
        val list = am.list(src) ?: emptyArray()
        if (list.isEmpty()) {
            try {
                dst.parentFile?.mkdirs()
                am.open(src).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
            } catch (e: IOException) { /* مجلد فاضي */ }
        } else {
            dst.mkdirs()
            for (n in list) copyDir(am, "$src/$n", File(dst, n))
        }
    }
}

class Heard(val text: String, val spk: DoubleArray?, val frames: Int)

/** بصمة صوتك: حفظ + مقارنة (cosine distance، أقل = أشبه). */
object VoiceId {
    const val THRESHOLD = 0.50       // للأمر: قلّله لو عايز أشد
    const val LOOSE = 0.75           // للاسم "لؤلؤ" لوحده (كلمة قصيرة فمتساهل أكتر)
    const val MIN_FRAMES_WAKE = 20
    const val MIN_FRAMES_ENROLL = 100

    fun parse(json: String): Heard {
        val o = JSONObject(json)
        val arr = o.optJSONArray("spk")
        val v = if (arr != null) DoubleArray(arr.length()) { arr.getDouble(it) } else null
        return Heard(o.optString("text"), v, o.optInt("spk_frames"))
    }

    fun save(ctx: Context, v: DoubleArray) {
        ctx.getSharedPreferences("lulu", Context.MODE_PRIVATE).edit()
            .putString("voiceprint", v.joinToString(",")).apply()
    }

    fun load(ctx: Context): DoubleArray? =
        ctx.getSharedPreferences("lulu", Context.MODE_PRIVATE).getString("voiceprint", null)
            ?.split(",")?.map { it.toDouble() }?.toDoubleArray()

    fun dist(a: DoubleArray, b: DoubleArray): Double {
        var d = 0.0; var na = 0.0; var nb = 0.0
        for (i in a.indices) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        return 1 - d / (sqrt(na) * sqrt(nb))
    }
}

object UiLog {
    @Volatile var sink: ((String) -> Unit)? = null
    fun d(m: String) {
        android.util.Log.d("Lulu", m)
        Handler(Looper.getMainLooper()).post { sink?.invoke(m) }
    }
}

open class L : RecognitionListener {
    override fun onPartialResult(hypothesis: String?) {}
    override fun onResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) { UiLog.d("خطأ: ${exception?.message}") }
    override fun onTimeout() {}
}
