package com.lulu.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.*
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var log: TextView
    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun btn(t: String, a: () -> Unit) =
            root.addView(Button(this).apply { text = t; setOnClickListener { a() } })

        btn("١) الصلاحيات العادية") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS, "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("٢) الصلاحيات الخاصة (اضغط لحد ما تخلص)") { special() }
        btn("٣) تفعيل الإرسال التلقائي في واتساب") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("٤) سجّل صوتي (٢٠ ثانية)") { enroll() }
        btn("٥) شغّل لؤلؤ") { startForegroundService(Intent(this, LuluService::class.java)) }
        btn("إيقاف لؤلؤ") { stopService(Intent(this, LuluService::class.java)) }

        log = TextView(this).apply { textSize = 14f }
        root.addView(ScrollView(this).apply { addView(log) })
        setContentView(root)
        UiLog.sink = { log.append(it + "\n") }
    }

    private fun special() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            return
        }
        UiLog.d("الصلاحيات الخاصة تمام ✔")
    }

    private fun enroll() {
        UiLog.d("بحمّل الموديل...")
        thread {
            try { Engine.load(this) } catch (e: Exception) {
                UiLog.d("الموديلات مش في assets: ${e.message}"); return@thread
            }
            h.post { runEnroll() }
        }
    }

    private fun runEnroll() {
        UiLog.d("اتكلم بصوتك الطبيعي ٢٠ ثانية. مثلاً: لؤلؤ افتح واتساب. لؤلؤ ابعت لأحمد قوله أنا جاي. وكمّل كلام عادي.")
        val rec = Recognizer(Engine.model, 16000f).also { it.setSpeakerModel(Engine.spk) }
        val vecs = ArrayList<DoubleArray>()
        val s = SpeechService(rec, 16000f)
        fun collect(hyp: String?) {
            val r = VoiceId.parse(hyp ?: return)
            if (r.spk != null && r.frames >= VoiceId.MIN_FRAMES_ENROLL) vecs.add(r.spk)
        }
        s.startListening(object : L() {
            override fun onResult(hypothesis: String?) = collect(hypothesis)
            override fun onFinalResult(hypothesis: String?) = collect(hypothesis)
        })
        h.postDelayed({
            s.stop()
            h.postDelayed({
                s.shutdown()
                if (vecs.size >= 2) {
                    VoiceId.save(this, DoubleArray(vecs[0].size) { i -> vecs.sumOf { it[i] } / vecs.size })
                    UiLog.d("اتسجّل صوتك ✔ (${vecs.size} عينات)")
                } else UiLog.d("الصوت قليل، جرّب تاني واتكلم أكتر وبصوت أعلى")
            }, 800)
        }, 20000)
    }
}
