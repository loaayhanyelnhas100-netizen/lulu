package com.lulu.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract

object Commands {
    const val COUNTRY_CODE = "20"   // مصر 20 | السودان 249 — غيّره حسب رقمك

    private val known = mapOf(
        "واتساب" to "com.whatsapp", "واتس اب" to "com.whatsapp",
        "يوتيوب" to "com.google.android.youtube", "كروم" to "com.android.chrome",
        "فيسبوك" to "com.facebook.katana", "تيليجرام" to "org.telegram.messenger",
        "انستجرام" to "com.instagram.android", "ماسنجر" to "com.facebook.orca"
    )

    fun norm(s: String) = s.replace(Regex("[\\u064B-\\u0652]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ة', 'ه').replace('ى', 'ي').trim()

    fun run(ctx: Context, raw: String): String {
        val t = norm(raw)

        // "ابعت لأحمد قوله أنا جاي"
        Regex("^(?:ابعت|ارسل|ابعتلي)\\s*(?:واتساب|رساله)?\\s*(.+?)\\s+(?:قوله|قولو|وقوله|يقول|رساله|مفاده)\\s+(.+)$")
            .find(t)?.let { m ->
                var name = m.groupValues[1].removePrefix("الي ").removePrefix("ل ").trim()
                val body = if (raw.length == t.length) raw.substring(m.groups[2]!!.range) else m.groupValues[2]
                var number = findContact(ctx, name)
                if (number == null && name.startsWith("ل")) {
                    name = name.drop(1)
                    number = findContact(ctx, name)
                }
                if (number == null) return "مش لاقي جهة اتصال باسم $name"
                return sendWhatsApp(ctx, number, body, name)
            }

        // "افتح واتساب"
        Regex("^(?:افتح|شغل|روح علي|روح الي)\\s+(?:تطبيق\\s+)?(.+)$").find(t)?.let { m ->
            val name = m.groupValues[1]
            val pkg = findApp(ctx, name) ?: return "مش لاقي تطبيق اسمه $name"
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "مش قادر أفتحه"
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "تمام، فتحت $name"
        }
        return "مفهمتش الأمر"
    }

    private fun findApp(ctx: Context, name: String): String? {
        known.entries.firstOrNull { name.contains(norm(it.key)) }?.let { return it.value }
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0).firstOrNull {
            norm(it.loadLabel(pm).toString()).lowercase().contains(name.lowercase())
        }?.activityInfo?.packageName
    }

    private fun findContact(ctx: Context, name: String): String? {
        val p = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cols = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER)
        val target = norm(name).lowercase()
        ctx.contentResolver.query(p, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                if (norm(c.getString(0) ?: "").lowercase().contains(target)) return c.getString(1)
            }
        }
        return null
    }

    private fun sendWhatsApp(ctx: Context, number: String, msg: String, name: String): String {
        var d = number.filter { it.isDigit() }
        d = when {
            number.trim().startsWith("+") -> d
            d.startsWith("00") -> d.drop(2)
            d.startsWith("0") -> COUNTRY_CODE + d.drop(1)
            else -> d
        }
        val armed = SendAccessibility.enabled(ctx)
        if (armed) SendAccessibility.arm()
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$d?text=${Uri.encode(msg)}"))
            .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return if (armed) "بعتّ الرسالة لـ $name" else "كتبت الرسالة لـ $name، دوس إرسال"
    }
}
