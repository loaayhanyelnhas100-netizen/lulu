package com.lulu.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** بيدوس زر "إرسال" في واتساب بعد ما لؤلؤ يفتح المحادثة بالنص. */
class SendAccessibility : AccessibilityService() {
    companion object {
        @Volatile var armedUntil = 0L
        fun arm() { armedUntil = System.currentTimeMillis() + 15000 }
        fun enabled(ctx: Context): Boolean =
            (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
                .contains(ctx.packageName)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (System.currentTimeMillis() > armedUntil) return
        if (e?.packageName?.toString() != "com.whatsapp") return
        val root = rootInActiveWindow ?: return
        val node = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull()
            ?: root.findAccessibilityNodeInfosByText("Send").firstOrNull()
            ?: root.findAccessibilityNodeInfosByText("إرسال").firstOrNull()
        if (node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) armedUntil = 0
    }

    override fun onInterrupt() {}
}
